let currentUser = null;
let simulatedUsers = [];
let simulatedShelters = [{ name: 'Albergue de Prueba', city: 'CDMX', email: 'albergue@test.com', rpc: 'RPC123', cud: 'CUD123', owner: 'Test Owner' }];
let simulatedPets = [
    { id: 1, name: 'Max', species: 'perro', age: 3, breed: 'Golden Retriever', size: 'grande', sex: 'macho', color: 'Dorado', secColor: '', behavior: 'juguetón y familiar', coexistence: ['Niños', 'Otros perros'], coatPattern: 'Sólido', coatType: 'Medio', disability: 'Ninguna', ailments: 'Ninguno', vaccines: ['Rabia', 'Parvovirus'], treatments: 'Ninguno', distinguishingMarks: 'Ninguna', photo: 'https://via.placeholder.com/150/FF0000/FFFFFF?text=Max', status: 'Disponible', shelter: 'Albergue de Prueba', city: 'CDMX' },
    { id: 2, name: 'Luna', species: 'gato', age: 1, breed: 'Mestizo', size: 'mediano', sex: 'hembra', color: 'Gris', secColor: '', behavior: 'tranquilo y cariñoso', coexistence: ['Adultos'], coatPattern: 'Atigrado', coatType: 'Corto', disability: 'Ninguna', ailments: 'Ninguno', vaccines: ['Rabia', 'Herpesvirus'], treatments: 'Ninguno', distinguishingMarks: 'Oreja doblada', photo: 'https://via.placeholder.com/150/0000FF/FFFFFF?text=Luna', status: 'En Proceso', shelter: 'Albergue de Prueba', city: 'CDMX', adopterId: 1 },
    { id: 3, name: 'Toby', species: 'perro', age: 5, breed: 'Chihuahua', size: 'pequeno', sex: 'macho', color: 'Café', secColor: 'Crema', behavior: 'tímido con extraños', coexistence: ['Ninguno'], coatPattern: 'Bicolor', coatType: 'Largo', disability: 'Ninguna', ailments: 'Ninguno', vaccines: ['Rabia', 'Moquillo'], treatments: 'Ninguno', distinguishingMarks: 'Ninguna', photo: 'https://via.placeholder.com/150/FFFF00/000000?text=Toby', status: 'Disponible', shelter: 'Albergue de Prueba', city: 'CDMX' },
    { id: 4, name: 'Milo', species: 'gato', age: 2, breed: 'Siamés', size: 'pequeno', sex: 'macho', color: 'Crema', secColor: 'Marrón', behavior: 'energético y juguetón', coexistence: ['Niños'], coatPattern: 'Puntos de Color', coatType: 'Corto', disability: 'Ninguna', ailments: 'Ninguno', vaccines: ['Rabia'], treatments: 'Ninguno', distinguishingMarks: 'Cola corta', photo: 'https://via.placeholder.com/150/FF00FF/FFFFFF?text=Milo', status: 'Disponible', shelter: 'Albergue de Prueba', city: 'CDMX' },
];
let nextPetId = 5;

const views = ['home', 'public-pets', 'about-us-page', 'success-stories', 'select-role', 'login-form', 'adoptante-registration', 'shelter-registration', 'admin-registration', 'match-form', 'match-results', 'adoptante-panel', 'admin-panel', 'add-pet-form', 'edit-pet-form', 'pet-details-page'];

const breeds = {
    perro: ['Golden Retriever', 'Chihuahua', 'Pastor Alemán', 'Labrador', 'Poodle', 'Bulldog', 'Mestizo'],
    gato: ['Siamés', 'Persa', 'Mestizo', 'Maine Coon', 'Bengala', 'Ragdoll']
};

function showView(viewId) {
    views.forEach(id => {
        document.getElementById(id).classList.add('hidden');
    });
    document.getElementById(viewId).classList.remove('hidden');
}

function updateNav() {
    const nav = document.querySelector('.nav');
    nav.innerHTML = '';
    const navLinks = [
        { text: 'Inicio', view: 'home' },
        { text: 'Explorar', view: 'public-pets' },
        { text: 'Casos Exitosos', view: 'success-stories' },
        { text: 'Quiénes Somos', view: 'about-us-page' }
    ];

    navLinks.forEach(link => {
        const a = document.createElement('a');
        a.href = '#';
        a.textContent = link.text;
        a.onclick = () => showView(link.view);
        nav.appendChild(a);
    });

    if (currentUser) {
        const profileBtn = document.createElement('button');
        profileBtn.textContent = `Mi Perfil`;
        profileBtn.onclick = () => {
            if (currentUser.role === 'adoptante') {
                showAdoptantePanel();
            } else if (currentUser.role === 'admin') {
                showAdminPanel();
            }
        };
        nav.appendChild(profileBtn);

        const logoutBtn = document.createElement('button');
        logoutBtn.textContent = 'Cerrar Sesión';
        logoutBtn.onclick = logout;
        nav.appendChild(logoutBtn);
    } else {
        const loginBtn = document.createElement('button');
        loginBtn.textContent = 'Iniciar Sesión';
        loginBtn.classList.add('btn', 'btn-green');
        loginBtn.onclick = () => showView('login-form');
        nav.appendChild(loginBtn);
    }
}

function logout() {
    currentUser = null;
    alert('Has cerrado sesión.');
    updateNav();
    showView('home');
}

function showPublicPets() {
    renderPets();
    showView('public-pets');
}

function renderPets() {
    const petList = document.getElementById('pet-list');
    petList.innerHTML = '';
    simulatedPets.filter(pet => pet.status === 'Disponible').forEach(pet => {
        const petCard = document.createElement('div');
        petCard.className = 'pet-card';
        petCard.innerHTML = `
            <img src="${pet.photo}" alt="Foto de ${pet.name}">
            <div class="pet-details">
                <div class="pet-name">${pet.name}</div>
                <div class="pet-info">
                    <strong>Especie:</strong> ${pet.species} | 
                    <strong>Raza:</strong> ${pet.breed} | 
                    <strong>Sexo:</strong> ${pet.sex} | 
                    <strong>Edad:</strong> ${pet.age} años
                </div>
                <div class="pet-info"><strong>Albergue:</strong> ${pet.shelter}</div>
                <div class="pet-info"><strong>Ubicación:</strong> ${pet.city}</div>
                <span class="adoption-status status-${pet.status.replace(/\s/g, '-')}" style="margin-top: 10px;">${pet.status}</span>
            </div>
            <div class="pet-actions">
                <button class="btn btn-green" onclick="showPetDetails(${pet.id})">Ver Detalles</button>
            </div>
        `;
        petList.appendChild(petCard);
    });
}

function showPetDetails(petId) {
    const pet = simulatedPets.find(p => p.id === petId);
    if (!pet) {
        alert('Mascota no encontrada.');
        return;
    }

    const detailsView = document.getElementById('pet-details-view');
    detailsView.innerHTML = `
        <img src="${pet.photo}" alt="Foto de ${pet.name}">
        <h2>${pet.name}</h2>
        <span class="adoption-status status-${pet.status.replace(/\s/g, '-')}" style="margin-top: 10px;">${pet.status}</span>
        <p style="color: #7f8c8d; margin-top: 5px;">Albergue: ${pet.shelter} | Ubicación: ${pet.city}</p>
        <div class="details-grid">
            <p><strong>Especie:</strong> ${pet.species}</p>
            <p><strong>Raza:</strong> ${pet.breed}</p>
            <p><strong>Edad:</strong> ${pet.age} años</p>
            <p><strong>Sexo:</strong> ${pet.sex}</p>
            <p><strong>Tamaño:</strong> ${pet.size}</p>
            <p><strong>Color:</strong> ${pet.color} ${pet.secColor ? `y ${pet.secColor}` : ''}</p>
            <p><strong>Patrón de Pelo:</strong> ${pet.coatPattern || 'No especificado'}</p>
            <p><strong>Tipo de Pelo:</strong> ${pet.coatType || 'No especificado'}</p>
            <p><strong>Señas Particulares:</strong> ${pet.distinguishingMarks || 'Ninguna'}</p>
            <p><strong>Comportamiento:</strong> ${pet.behavior || 'No especificado'}</p>
            <p><strong>Convive con:</strong> ${pet.coexistence.join(', ') || 'No especificado'}</p>
            <p><strong>Padecimientos:</strong> ${pet.ailments || 'Ninguno'}</p>
            <p><strong>Vacunas:</strong> ${pet.vaccines.join(', ') || 'Ninguna'}</p>
            <p><strong>Tratamientos:</strong> ${pet.treatments || 'Ninguno'}</p>
        </div>
        <div style="margin-top: 20px;">
            <button class="btn" onclick="showPublicPets()">Regresar</button>
            ${currentUser && currentUser.role === 'adoptante' ? `
                <button class="btn btn-green" onclick="addToFavorites(${pet.id})">Guardar en Favoritos</button>
                <button class="btn btn-green" onclick="scheduleAppointment(${pet.id})">Agendar Cita</button>
            ` : ''}
        </div>
    `;
    showView('pet-details-page');
}

function showSelectRole() {
    document.getElementById('adminShelter').innerHTML = '<option value="">Selecciona tu albergue...</option>' + simulatedShelters.map(s => `<option value="${s.name}">${s.name}</option>`).join('');
    showView('select-role');
}

function showAdoptanteRegistration() { showView('adoptante-registration'); }
function showShelterRegistration() { showView('shelter-registration'); }
function showAdminRegistration() { showView('admin-registration'); }

function submitLoginForm(event) {
    event.preventDefault();
    const identifier = document.getElementById('loginIdentifier').value;
    const password = document.getElementById('loginPassword').value;

    const user = simulatedUsers.find(u => (u.email === identifier || u.id === identifier) && u.password === password);
    if (user) {
        currentUser = user;
        alert(`¡Bienvenido, ${currentUser.name}!`);
        updateNav();
        if (currentUser.role === 'adoptante') {
            showAdoptantePanel();
        } else if (currentUser.role === 'admin') {
            showAdminPanel();
        }
    } else {
        alert('Identificador o contraseña incorrectos.');
    }
}

function submitAdoptanteRegistration(event) {
    event.preventDefault();
    const email = document.getElementById('adopEmail').value;
    if (simulatedUsers.some(user => user.email === email)) {
        alert('Este correo electrónico ya está registrado.');
        return;
    }

    const newUser = {
        id: simulatedUsers.length + 1,
        role: 'adoptante',
        name: document.getElementById('adopName').value,
        primerApellido: document.getElementById('adopPrimerApellido').value,
        segundoApellido: document.getElementById('adopSegundoApellido').value,
        fechaNacimiento: document.getElementById('fechaNacimiento').value,
        sexo: document.getElementById('adopSexo').value,
        email: email,
        password: document.getElementById('adopPassword').value,
        telefono: document.getElementById('adopTelefono').value,
        telefonoEmergencia: document.getElementById('adopTelefonoEmergencia').value,
        direccion: document.getElementById('adopDireccion').value,
        city: document.getElementById('adopCity').value,
        cp: document.getElementById('adopCP').value,
        numHabitantes: document.getElementById('adopNumHabitantes').value,
        kids: document.querySelector('input[name="adopKids"]:checked').value === 'si',
        kidsAge: document.getElementById('adopKidsAge').value,
        experiencia: document.getElementById('adopExperiencia').value,
        presupuesto: document.getElementById('adopPresupuesto').value,
        favorites: [],
        appointments: [],
        photo: document.getElementById('previewProfilePhoto').src
    };

    simulatedUsers.push(newUser);
    currentUser = newUser;
    alert('¡Registro de Adoptante exitoso!');
    updateNav();
    showAdoptantePanel();
}

function submitShelterRegistration(event) {
    event.preventDefault();
    const email = document.getElementById('shelterEmail').value;
    if (simulatedShelters.some(shelter => shelter.email === email)) {
        alert('Este albergue ya está registrado.');
        return;
    }

    const newShelter = {
        id: simulatedShelters.length + 1,
        name: document.getElementById('shelterName').value,
        city: document.getElementById('shelterCity').value,
        email: email,
        telefono: document.getElementById('shelterTelefono').value,
        rpc: document.getElementById('shelterRPC').value,
        cud: document.getElementById('shelterCUD').value,
        owner: document.getElementById('shelterOwner').value
    };
    simulatedShelters.push(newShelter);
    alert('¡Registro de Albergue exitoso! Ahora tus administradores pueden registrarse.');
    showSelectRole();
}

function submitAdminRegistration(event) {
    event.preventDefault();
    const adminId = document.getElementById('adminId').value;
    const adminShelterName = document.getElementById('adminShelter').value;

    if (simulatedUsers.some(user => user.id === adminId)) {
        alert('Este ID de trabajador ya está en uso.');
        return;
    }

    if (!simulatedShelters.some(shelter => shelter.name === adminShelterName)) {
        alert('El albergue seleccionado no existe. Por favor, asegúrate de que esté registrado.');
        return;
    }

    const newAdmin = {
        id: adminId,
        role: 'admin',
        name: document.getElementById('adminName').value,
        password: document.getElementById('adminPassword').value,
        shelter: adminShelterName
    };
    simulatedUsers.push(newAdmin);
    currentUser = newAdmin;
    alert('¡Registro de Administrador exitoso!');
    updateNav();
    showAdminPanel();
}

function showAdoptantePanel() {
    if (!currentUser || currentUser.role !== 'adoptante') {
        alert('Necesitas ser un adoptante para ver este panel.');
        showView('login-form');
        return;
    }
    renderAdoptanteProfile();
    renderFavorites();
    renderAppointments();
    showView('adoptante-panel');
}

function renderAdoptanteProfile() {
    const profileDisplay = document.getElementById('profile-details-display');
    profileDisplay.innerHTML = `
        <div class="profile-photo-container">
            <img src="${currentUser.photo || 'https://via.placeholder.com/150/EEEEEE/888888?text=Perfil'}" alt="Foto de Perfil">
        </div>
        <p><strong>Nombre Completo:</strong> ${currentUser.name} ${currentUser.primerApellido} ${currentUser.segundoApellido || ''}</p>
        <p><strong>Correo Electrónico:</strong> ${currentUser.email}</p>
        <p><strong>Teléfono:</strong> ${currentUser.telefono}</p>
        <p><strong>Dirección:</strong> ${currentUser.direccion}, ${currentUser.city}, ${currentUser.cp}</p>
        <p><strong>Número de Habitantes en el hogar:</strong> ${currentUser.numHabitantes}</p>
        <p><strong>Experiencia con Mascotas:</strong> ${currentUser.experiencia}</p>
        <p><strong>Presupuesto Mensual:</strong> ${currentUser.presupuesto}</p>
    `;
}

function renderFavorites() {
    const favoritesList = document.getElementById('favorites-list');
    favoritesList.innerHTML = '';
    if (currentUser.favorites.length === 0) {
        favoritesList.innerHTML = '<p>Aún no has guardado ninguna mascota en tus favoritos.</p>';
    } else {
        currentUser.favorites.forEach(petId => {
            const pet = simulatedPets.find(p => p.id === petId);
            if (pet) {
                 const petCard = document.createElement('div');
                 petCard.className = 'pet-card';
                 petCard.innerHTML = `
                     <img src="${pet.photo}" alt="Foto de ${pet.name}">
                     <div class="pet-details">
                         <div class="pet-name">${pet.name}</div>
                         <div class="pet-info">
                             <strong>Especie:</strong> ${pet.species} | 
                             <strong>Raza:</strong> ${pet.breed} | 
                             <strong>Sexo:</strong> ${pet.sex} | 
                             <strong>Edad:</strong> ${pet.age} años
                         </div>
                         <div class="pet-info"><strong>Albergue:</strong> ${pet.shelter}</div>
                         <span class="adoption-status status-${pet.status.replace(/\s/g, '-')}" style="margin-top: 10px;">${pet.status}</span>
                     </div>
                     <div class="pet-actions">
                         <button class="btn" onclick="removeFavorite(${pet.id})">Quitar de Favoritos</button>
                         <button class="btn btn-green" onclick="scheduleAppointment(${pet.id})">Agendar Cita</button>
                     </div>
                 `;
                 favoritesList.appendChild(petCard);
            }
        });
    }
}

function renderAppointments() {
     const appointmentsSection = document.getElementById('adoption-status-section');
     appointmentsSection.innerHTML = '';
     if (currentUser.appointments.length === 0) {
         appointmentsSection.innerHTML = '<p>No tienes ningún proceso de adopción activo.</p>';
     } else {
         currentUser.appointments.forEach(app => {
             const pet = simulatedPets.find(p => p.id === app.petId);
             const statusText = app.status === 'pending' ? 'Pendiente' : 'Aprobada';
             const statusClass = app.status === 'pending' ? 'status-En-Proceso' : 'status-Adoptado';
             appointmentsSection.innerHTML += `
                 <div class="pet-card">
                     <div class="pet-details">
                         <div class="pet-name">Cita con ${pet.name}</div>
                         <p><strong>Albergue:</strong> ${pet.shelter}</p>
                         <p><strong>Fecha y Hora:</strong> ${app.dateTime}</p>
                         <p><strong>Estado:</strong> <span class="adoption-status ${statusClass}">${statusText}</span></p>
                     </div>
                 </div>
             `;
         });
     }
 }

function addToFavorites(petId) {
    if (!currentUser) {
        alert('Debes iniciar sesión para guardar favoritos.');
        return;
    }
    if (currentUser.favorites.includes(petId)) {
        alert('Esta mascota ya está en tus favoritos.');
    } else {
        currentUser.favorites.push(petId);
        alert('Mascota agregada a favoritos.');
        renderFavorites();
    }
}

function removeFavorite(petId) {
    currentUser.favorites = currentUser.favorites.filter(id => id !== petId);
    alert('Mascota eliminada de favoritos.');
    renderFavorites();
}

function scheduleAppointment(petId) {
    if (!currentUser) {
        alert('Debes iniciar sesión para agendar una cita.');
        return;
    }
    const pet = simulatedPets.find(p => p.id === petId);
    const appointmentTime = prompt(`Por favor, ingresa una fecha y hora para la cita con ${pet.name} (Ej: 2023-10-27 15:00):`);
    if (appointmentTime) {
        currentUser.appointments.push({ petId, dateTime: appointmentTime, status: 'pending' });
        alert(`Cita agendada para el ${appointmentTime}. El albergue revisará tu solicitud.`);
        renderAppointments();
    }
}

function showAdminPanel() {
    if (!currentUser || currentUser.role !== 'admin') {
        alert('Necesitas ser un administrador para ver este panel.');
        showView('login-form');
        return;
    }
    renderAdminPets();
    showView('admin-panel');
}

function renderAdminPets() {
    const adminPetList = document.getElementById('admin-pet-list');
    adminPetList.innerHTML = '';
    const myShelterPets = simulatedPets.filter(pet => pet.shelter === currentUser.shelter);
    if (myShelterPets.length === 0) {
        adminPetList.innerHTML = '<p>Aún no has registrado mascotas para tu albergue.</p>';
    } else {
        myShelterPets.forEach(pet => {
            const petCard = document.createElement('div');
            petCard.className = 'pet-card';
            petCard.innerHTML = `
                <img src="${pet.photo}" alt="Foto de ${pet.name}">
                <div class="pet-details">
                    <div class="pet-name">${pet.name}</div>
                    <div class="pet-info">
                        <strong>Especie:</strong> ${pet.species} | 
                        <strong>Raza:</strong> ${pet.breed} | 
                        <strong>Estado:</strong> <span class="adoption-status status-${pet.status.replace(/\s/g, '-')}" style="margin-top: 10px;">${pet.status}</span>
                    </div>
                </div>
                <div class="pet-actions">
                    <button class="btn" onclick="showEditPetForm(${pet.id})">Editar</button>
                    <button class="btn" onclick="deletePet(${pet.id})">Eliminar</button>
                </div>
            `;
            adminPetList.appendChild(petCard);
        });
    }
}

function deletePet(petId) {
    if (confirm('¿Estás seguro de que quieres dar de baja a esta mascota?')) {
        const petIndex = simulatedPets.findIndex(p => p.id === petId);
        if (petIndex > -1) {
            simulatedPets[petIndex].status = 'Baja';
            alert('Mascota dada de baja.');
            renderAdminPets();
        }
    }
}

function showAddPetForm() {
    document.getElementById('petForm').reset();
    updateBreeds();
    showView('add-pet-form');
}

function submitPetForm(event) {
    event.preventDefault();
    const newPet = {
        id: nextPetId++,
        name: document.getElementById('petName').value,
        species: document.getElementById('petSpecies').value,
        breed: document.getElementById('petBreed').value,
        age: new Date().getFullYear() - new Date(document.getElementById('fechaNacimiento-pet').value).getFullYear(),
        size: document.getElementById('petSize').value,
        sex: document.getElementById('petSex').value,
        color: document.getElementById('petColor').value,
        secColor: document.getElementById('petSecColor').value,
        coatPattern: document.getElementById('petCoatPattern').value,
        coatType: document.getElementById('petCoatType').value,
        distinguishingMarks: document.getElementById('petDistinguishingMarks').value,
        behavior: document.getElementById('petBehavior').value,
        coexistence: document.getElementById('petCoexistence').value.split(',').map(s => s.trim()),
        ailments: document.getElementById('petAilments').value,
        vaccines: document.getElementById('petVaccines').value.split(',').map(s => s.trim()),
        treatments: document.getElementById('petTreatments').value,
        photo: document.getElementById('petPhoto').value,
        status: 'Disponible',
        shelter: currentUser.shelter,
        city: simulatedShelters.find(s => s.name === currentUser.shelter).city
    };
    simulatedPets.push(newPet);
    alert('Mascota registrada exitosamente.');
    showAdminPanel();
}

function showEditPetForm(petId) {
    const pet = simulatedPets.find(p => p.id === petId);
    if (!pet) return;

    document.getElementById('editPetId').value = pet.id;
    document.getElementById('editPetName').value = pet.name;
    document.getElementById('editPetSpecies').value = pet.species;
    document.getElementById('editPetSize').value = pet.size;
    document.getElementById('editPetSex').value = pet.sex;
    document.getElementById('editPetColor').value = pet.color;
    document.getElementById('editPetSecColor').value = pet.secColor;
    document.getElementById('editPetCoatPattern').value = pet.coatPattern;
    document.getElementById('editPetCoatType').value = pet.coatType;
    document.getElementById('editPetDistinguishingMarks').value = pet.distinguishingMarks;
    document.getElementById('editPetBehavior').value = pet.behavior;
    document.getElementById('editPetCoexistence').value = pet.coexistence.join(', ');
    document.getElementById('editPetAilments').value = pet.ailments;
    document.getElementById('editPetVaccines').value = pet.vaccines.join(', ');
    document.getElementById('editPetTreatments').value = pet.treatments;
    document.getElementById('editPetPhoto').value = pet.photo;
    document.getElementById('editPetStatus').value = pet.status;

    updateEditBreeds();
    document.getElementById('editPetBreed').value = pet.breed;
    document.getElementById('editFechaNacimiento-pet').value = new Date(new Date().getFullYear() - pet.age, 0, 1).toISOString().substring(0, 10);

    showView('edit-pet-form');
}

function submitEditPet(event) {
    event.preventDefault();
    const petId = parseInt(document.getElementById('editPetId').value);
    const petIndex = simulatedPets.findIndex(p => p.id === petId);

    if (petIndex > -1) {
        simulatedPets[petIndex] = {
            id: petId,
            name: document.getElementById('editPetName').value,
            species: document.getElementById('editPetSpecies').value,
            breed: document.getElementById('editPetBreed').value,
            age: new Date().getFullYear() - new Date(document.getElementById('editFechaNacimiento-pet').value).getFullYear(),
            size: document.getElementById('editPetSize').value,
            sex: document.getElementById('editPetSex').value,
            color: document.getElementById('editPetColor').value,
            secColor: document.getElementById('editPetSecColor').value,
            coatPattern: document.getElementById('editPetCoatPattern').value,
            coatType: document.getElementById('editPetCoatType').value,
            distinguishingMarks: document.getElementById('editPetDistinguishingMarks').value,
            behavior: document.getElementById('editPetBehavior').value,
            coexistence: document.getElementById('editPetCoexistence').value.split(',').map(s => s.trim()),
            ailments: document.getElementById('editPetAilments').value,
            vaccines: document.getElementById('editPetVaccines').value.split(',').map(s => s.trim()),
            treatments: document.getElementById('editPetTreatments').value,
            photo: document.getElementById('editPetPhoto').value,
            status: document.getElementById('editPetStatus').value,
            shelter: currentUser.shelter,
            city: simulatedShelters.find(s => s.name === currentUser.shelter).city
        };
        alert('Mascota actualizada exitosamente.');
        showAdminPanel();
    }
}

function showMatchForm() {
    const albergueSelect = document.getElementById('albergue');
    albergueSelect.innerHTML = '<option value="">Todos los albergues</option>' + simulatedShelters.map(s => `<option value="${s.name}">${s.name}</option>`).join('');
    showView('match-form');
}

function submitMatchForm(event) {
    event.preventDefault();
    const tipoMascota = document.getElementById('tipoMascota').value;
    const tamanoMascota = document.getElementById('tamanoMascota').value;
    const nivelActividad = document.getElementById('nivelActividad').value;
    const espacioVivienda = document.getElementById('espacioVivienda').value;
    const conviveNinos = document.getElementById('conviveNinos').value;
    const experienciaMascotas = document.getElementById('experienciaMascotas').value;
    const albergue = document.getElementById('albergue').value;

    function calculateCompatibility(pet) {
        let score = 0;
        if (pet.species === tipoMascota) score += 20;
        if (pet.size === tamanoMascota) score += 15;
        if (pet.coexistence.includes('Niños') && conviveNinos === 'si') score += 15;
        if (pet.behavior.includes('juguetón') && nivelActividad === 'alto') score += 10;
        if (pet.behavior.includes('tranquilo') && nivelActividad === 'bajo') score += 10;
        if (albergue && pet.shelter === albergue) score += 20;
        return score;
    }

    const availablePets = simulatedPets.filter(p => p.status === 'Disponible');
    const sortedPets = availablePets.sort((a, b) => calculateCompatibility(b) - calculateCompatibility(a));
    const top3 = sortedPets.slice(0, 3);

    const resultsList = document.getElementById('match-results-list');
    resultsList.innerHTML = '';
    if (top3.length === 0) {
        resultsList.innerHTML = '<p class="alert-box">Lo sentimos, no se encontraron mascotas que coincidan con tus criterios. ¡Pero no te desanimes, puedes explorar todas las mascotas disponibles!</p>';
    } else {
        top3.forEach(pet => {
            const petCard = document.createElement('div');
            petCard.className = 'pet-card';
            petCard.innerHTML = `
                <img src="${pet.photo}" alt="Foto de ${pet.name}">
                <div class="pet-details">
                    <div class="pet-name">${pet.name}</div>
                    <div class="pet-info">
                        <strong>Raza:</strong> ${pet.breed} | 
                        <strong>Edad:</strong> ${pet.age} años | 
                        <strong>Tamaño:</strong> ${pet.size}
                    </div>
                    <div class="pet-info"><strong>Albergue:</strong> ${pet.shelter}</div>
                    <div class="pet-info"><strong>Ubicación:</strong> ${pet.city}</div>
                    <div class="pet-info"><strong>Comportamiento:</strong> ${pet.behavior}</div>
                </div>
                <div class="pet-actions">
                     <button class="btn btn-green" onclick="showPetDetails(${pet.id})">Ver Detalles</button>
                </div>
            `;
            resultsList.appendChild(petCard);
        });
    }
    
    const matchActions = document.getElementById('match-actions');
    matchActions.innerHTML = '';
    if (currentUser && currentUser.role === 'adoptante') {
        top3.forEach(pet => {
             matchActions.innerHTML += `
                 <button class="btn btn-green" onclick="addToFavorites(${pet.id})">Guardar a ${pet.name} en Favoritos</button>
                 <button class="btn btn-green" onclick="scheduleAppointment(${pet.id})">Agendar Cita con ${pet.name}</button>
             `;
        });
    } else {
        matchActions.innerHTML = `<p class="alert-box">¡Inicia sesión para guardar favoritos o agendar citas!</p>`;
    }

    showView('match-results');
}

function updateBreeds() {
    const species = document.getElementById('petSpecies').value;
    const breedSelect = document.getElementById('petBreed');
    if (species) {
        const breedOptions = breeds[species].map(breed => `<option value="${breed}">${breed}</option>`).join('');
        breedSelect.innerHTML = `<option value="">Seleccionar...</option>${breedOptions}`;
        breedSelect.disabled = false;
    } else {
        breedSelect.innerHTML = '<option value="">Selecciona una especie primero...</option>';
        breedSelect.disabled = true;
    }
}

function updateEditBreeds() {
    const species = document.getElementById('editPetSpecies').value;
    const breedSelect = document.getElementById('editPetBreed');
    if (species) {
        const breedOptions = breeds[species].map(breed => `<option value="${breed}">${breed}</option>`).join('');
        breedSelect.innerHTML = `<option value="">Seleccionar...</option>${breedOptions}`;
        breedSelect.disabled = false;
    } else {
        breedSelect.innerHTML = '<option value="">Selecciona una especie primero...</option>';
        breedSelect.disabled = true;
    }
}

function previewProfilePhotoFile(input) {
    const preview = document.getElementById('previewProfilePhoto');
    const file = input.files[0];
    const reader = new FileReader();

    reader.onloadend = function () {
        preview.src = reader.result;
        preview.style.display = 'block';
    }

    if (file) {
        reader.readAsDataURL(file);
    } else {
        preview.src = '';
        preview.style.display = 'none';
    }
}

function toggleAdoptanteTerms(event) {
    event.preventDefault();
    const termsContent = document.getElementById('adopTermsContent');
    termsContent.classList.toggle('hidden');
}

function toggleAdminTerms(event) {
    event.preventDefault();
    const termsContent = document.getElementById('adminTermsContent');
    termsContent.classList.toggle('hidden');
}

function toggleShelterTerms(event) {
    event.preventDefault();
    const termsContent = document.getElementById('shelterTermsContent');
    termsContent.classList.toggle('hidden');
}

function toggleKidsFields(show) {
    const kidsFields = document.getElementById('adopKidsFields');
    if (show) {
        kidsFields.classList.remove('hidden');
        document.getElementById('adopKidsAge').required = true;
    } else {
        kidsFields.classList.add('hidden');
        document.getElementById('adopKidsAge').required = false;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    updateNav();
    showView('home');
});