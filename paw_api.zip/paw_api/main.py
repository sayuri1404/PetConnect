"""
Paw Rescue API (Python/FastAPI) — listo para conectar tu front (pet3_db.js)

Cómo correr:
1) Crear venv e instalar:
   pip install -r requirements.txt
2) Configurar variables de entorno (o .env):
   DATABASE_URL="postgresql://USER:PASS@HOST:5432/DBNAME"
   JWT_SECRET="cambia-esto"
3) Ejecutar:
   uvicorn main:app --reload --port 8000

Tu front usa API_BASE="/api", así que esta app monta todo bajo /api.
"""

import os
from datetime import datetime, timedelta, date
from typing import Optional, List, Any, Dict

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, EmailStr, Field

import psycopg
from psycopg.rows import dict_row
from passlib.context import CryptContext
from jose import jwt, JWTError

# -----------------------------
# Config
# -----------------------------
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/postgres")
JWT_SECRET = os.getenv("JWT_SECRET", "dev-secret-change-me")
JWT_ALG = "HS256"
JWT_EXPIRES_MIN = int(os.getenv("JWT_EXPIRES_MIN", "720"))  # 12h

# Si tus columnas en SEPOMEX son distintas, ajusta aquí:
SEPOMEX_CODIGOS_TABLE = "sepomex.codigos"
SEPOMEX_ESTADO_TABLE = "sepomex.estado"
SEP_CP_COL = "codigo_postal"
SEP_ENTIDAD_ID_COL = "entidad_id"
SEP_MUNICIPIO_COL = "municipio"         # <- ajusta si se llama distinto
SEP_ASENTAMIENTO_COL = "asentamiento"   # <- ajusta si se llama distinto
SEP_ESTADO_NOMBRE_COL = "nombre"        # <- ajusta si se llama distinto

pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
bearer = HTTPBearer()

def db():
    # conexión por request (suficiente para demo); si quieres pool, lo armamos después
    with psycopg.connect(DATABASE_URL, row_factory=dict_row) as conn:
        yield conn

def create_access_token(payload: dict) -> str:
    now = datetime.utcnow()
    exp = now + timedelta(minutes=JWT_EXPIRES_MIN)
    to_encode = {**payload, "iat": int(now.timestamp()), "exp": exp}
    return jwt.encode(to_encode, JWT_SECRET, algorithm=JWT_ALG)

def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token inválido o expirado")

def get_current_user(creds: HTTPAuthorizationCredentials = Depends(bearer)) -> dict:
    return decode_token(creds.credentials)

def require_role(*roles: str):
    def _dep(user: dict = Depends(get_current_user)) -> dict:
        if user.get("rol") not in roles:
            raise HTTPException(status_code=403, detail="No autorizado para este recurso")
        return user
    return _dep

# -----------------------------
# Esquemas (Pydantic)
# -----------------------------
class RegisterIn(BaseModel):
    nombre: str
    email: EmailStr
    telefono: Optional[str] = None
    password: str = Field(min_length=6)
    rol: str = "adoptante"  # adoptante | fundacion | donador (puedes ampliar)

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class AuthOut(BaseModel):
    token: str
    user: dict

class MascotaOut(BaseModel):
    id_mascota: int
    nombre: Optional[str] = None
    edad: Optional[int] = None
    tamanio: Optional[str] = None
    sexo: Optional[str] = None
    url_foto: Optional[str] = None
    especie_id: Optional[int] = None

class SolicitudCreate(BaseModel):
    id_mascota: int

class PerfilUpsert(BaseModel):
    # Campos más comunes (puedes agregar los que falten, FastAPI permite extras si lo deseas)
    tipo_vivienda: Optional[str] = None
    tiene_patio: Optional[bool] = None
    vive_en_renta: Optional[bool] = None
    tiene_otras_mascotas: Optional[bool] = None
    convive_con_ninos: Optional[bool] = None
    horas_solo_dia: Optional[int] = None
    experiencia_previa: Optional[bool] = None
    notas: Optional[str] = None

    codigo_postal: Optional[str] = None
    asentamiento: Optional[str] = None
    calle: Optional[str] = None
    num_exterior: Optional[str] = None
    num_interior: Optional[str] = None

    situacion_vivienda: Optional[str] = None
    contacto_arrendador: Optional[str] = None
    espacio_cercado: Optional[str] = None

    adultos_hogar: Optional[int] = None
    personas_hogar: Optional[int] = None
    ninos_rango: Optional[List[str]] = None
    otras_mascotas: Optional[List[str]] = None
    otras_mascotas_detalle: Optional[str] = None

    nivel_experiencia: Optional[str] = None
    horas_fuera: Optional[str] = None
    nivel_actividad: Optional[str] = None
    gastos_vet: Optional[str] = None
    compromiso_esterilizacion: Optional[str] = None
    tiempo_dedicado: Optional[str] = None
    motivo_adopcion: Optional[str] = None
    que_haria_cambios: Optional[str] = None
    nivel_economico: Optional[str] = None

    edad: Optional[int] = None
    tel_movil: Optional[str] = None
    tel_fijo: Optional[str] = None
    email: Optional[EmailStr] = None

# -----------------------------
# App
# -----------------------------
app = FastAPI(title="Paw Rescue API", version="0.1.0")

# CORS (ajusta para tu host/puerto)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # para demo; luego restringe
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -----------------------------
# Auth helpers (tabla extra)
# -----------------------------
# Creamos una tabla auth sencilla porque paw.adoptante no trae password.
# Ver create_auth_tables.sql para crearla.
AUTH_TABLE = "paw.usuario_auth"

def get_auth_by_email(conn, email: str) -> Optional[dict]:
    q = f"SELECT * FROM {AUTH_TABLE} WHERE email = %s LIMIT 1"
    return conn.execute(q, (email,)).fetchone()

# -----------------------------
# Endpoints: AUTH
# -----------------------------
@app.post("/api/auth/register", response_model=Any)
def register(payload: RegisterIn, conn=Depends(db)):
    # 1) evitar duplicados
    if get_auth_by_email(conn, payload.email):
        raise HTTPException(status_code=409, detail="El email ya está registrado")

    rol = payload.rol.lower().replace("fundación", "fundacion")

    if rol != "adoptante":
        # Para demo, registramos solo adoptantes. Puedes extender a fundación/donador.
        raise HTTPException(status_code=400, detail="Por ahora solo se permite rol=adoptante en el demo")

    # 2) crear adoptante
    with conn.transaction():
        row = conn.execute(
            """
            INSERT INTO paw.adoptante (nombre, email, telefono, fecha_registro)
            VALUES (%s, %s, %s, CURRENT_DATE)
            RETURNING id_adoptante, nombre, email, telefono, fecha_registro
            """,
            (payload.nombre, payload.email, payload.telefono)
        ).fetchone()

        # 3) crear auth
        password_hash = pwd_ctx.hash(payload.password)
        conn.execute(
            f"""
            INSERT INTO {AUTH_TABLE} (email, password_hash, rol, id_adoptante, created_at)
            VALUES (%s, %s, %s, %s, NOW())
            """,
            (payload.email, password_hash, rol, row["id_adoptante"])
        )

    return {"message": "ok", "user": {**row, "rol": rol}}

@app.post("/api/auth/login", response_model=AuthOut)
def login(payload: LoginIn, conn=Depends(db)):
    auth = get_auth_by_email(conn, payload.email)
    if not auth or not pwd_ctx.verify(payload.password, auth["password_hash"]):
        raise HTTPException(status_code=401, detail="Credenciales incorrectas")

    # Traer datos del usuario (adoptante)
    user = conn.execute(
        "SELECT id_adoptante, nombre, email, telefono, fecha_registro FROM paw.adoptante WHERE id_adoptante = %s",
        (auth["id_adoptante"],)
    ).fetchone()

    if not user:
        raise HTTPException(status_code=401, detail="Usuario no válido en la base")

    token = create_access_token({
        "sub": auth["email"],
        "rol": auth["rol"],
        "id_adoptante": auth["id_adoptante"],
    })

    return {"token": token, "user": {**user, "rol": auth["rol"]}}

@app.get("/api/auth/me")
def me(user: dict = Depends(get_current_user), conn=Depends(db)):
    # Regresa el user actual desde DB
    adopt = conn.execute(
        "SELECT id_adoptante, nombre, email, telefono, fecha_registro FROM paw.adoptante WHERE id_adoptante=%s",
        (user["id_adoptante"],)
    ).fetchone()
    if not adopt:
        raise HTTPException(status_code=401, detail="Sesión inválida")
    return {"user": {**adopt, "rol": user["rol"]}}

# -----------------------------
# Endpoints: SEPOMEX (CP lookup)
# -----------------------------
@app.get("/api/sepomex/cp/{cp}")
def sepomex_cp(cp: str, conn=Depends(db)):
    clean = "".join([c for c in cp if c.isdigit()]).zfill(5)
    if len(clean) != 5:
        raise HTTPException(status_code=400, detail="CP inválido")

    # NOTA: Ajusta nombres de columnas si tu sepomex.codigos no usa municipio/asentamiento
    q = f"""
    SELECT
      c.{SEP_ENTIDAD_ID_COL} AS entidad_id,
      c.{SEP_MUNICIPIO_COL} AS municipio,
      c.{SEP_ASENTAMIENTO_COL} AS asentamiento,
      e.{SEP_ESTADO_NOMBRE_COL} AS estado
    FROM {SEPOMEX_CODIGOS_TABLE} c
    LEFT JOIN {SEPOMEX_ESTADO_TABLE} e
      ON e.{SEP_ENTIDAD_ID_COL} = c.{SEP_ENTIDAD_ID_COL}
    WHERE c.{SEP_CP_COL}::text = %s
    """
    rows = conn.execute(q, (clean,)).fetchall()
    if not rows:
        return {"codigo_postal": clean, "estado": None, "municipio": None, "asentamientos": []}

    estado = rows[0].get("estado")
    municipio = rows[0].get("municipio")
    asentamientos = sorted({r.get("asentamiento") for r in rows if r.get("asentamiento")})

    return {
        "codigo_postal": clean,
        "estado": estado,
        "municipio": municipio,
        "asentamientos": asentamientos
    }

# -----------------------------
# Endpoints: MASCOTAS
# -----------------------------
@app.get("/api/mascotas", response_model=List[MascotaOut])
def mascotas(especie: Optional[str] = None, tamanio: Optional[str] = None, edad: Optional[int] = None, conn=Depends(db)):
    where = []
    params: List[Any] = []

    if especie:
        sp = especie.lower()
        if sp in ("perro", "perros"):
            where.append("m.especie_id = 1")
        elif sp in ("gato", "gatos"):
            where.append("m.especie_id = 2")
        elif sp.isdigit():
            where.append("m.especie_id = %s")
            params.append(int(sp))

    if tamanio:
        where.append("lower(m.tamanio) = lower(%s)")
        params.append(tamanio)

    if edad is not None:
        where.append("m.edad = %s")
        params.append(edad)

    where_sql = ("WHERE " + " AND ".join(where)) if where else ""

    q = f"""
    SELECT m.id_mascota, m.nombre, m.edad, m.tamanio, m.sexo, m.url_foto, m.especie_id
    FROM paw.mascota_rescatada m
    {where_sql}
    ORDER BY m.id_mascota DESC
    LIMIT 200
    """
    return conn.execute(q, params).fetchall()

@app.get("/api/mascotas/{id_mascota}")
def mascota_detalle(id_mascota: int, conn=Depends(db)):
    # Tomamos rescate más reciente (si hay varios)
    q = """
    SELECT
      m.*,
      r.alcaldia,
      r.situacion,
      r.necesidades_especiales,
      r.fecha AS fecha_rescate
    FROM paw.mascota_rescatada m
    LEFT JOIN LATERAL (
      SELECT * FROM paw.rescate rr
      WHERE rr.id_mascota = m.id_mascota
      ORDER BY rr.fecha DESC
      LIMIT 1
    ) r ON TRUE
    WHERE m.id_mascota = %s
    """
    row = conn.execute(q, (id_mascota,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Mascota no encontrada")
    return row

# -----------------------------
# Endpoints: SOLICITUDES
# -----------------------------
@app.post("/api/solicitudes")
def crear_solicitud(payload: SolicitudCreate, user=Depends(require_role("adoptante")), conn=Depends(db)):
    id_adoptante = user["id_adoptante"]
    id_mascota = payload.id_mascota

    # evitar duplicar solicitudes abiertas
    exists = conn.execute(
        """
        SELECT 1 FROM paw.solicitud_adopcion
        WHERE id_adoptante=%s AND id_mascota=%s AND estado IN ('pendiente','en_revision')
        LIMIT 1
        """,
        (id_adoptante, id_mascota)
    ).fetchone()
    if exists:
        return {"message": "ok", "note": "Ya existía una solicitud abierta"}

    with conn.transaction():
        row = conn.execute(
            """
            INSERT INTO paw.solicitud_adopcion (id_adoptante, id_mascota, fecha_solicitud, estado)
            VALUES (%s, %s, CURRENT_DATE, 'pendiente')
            RETURNING id_solicitud, id_adoptante, id_mascota, fecha_solicitud, estado
            """,
            (id_adoptante, id_mascota)
        ).fetchone()
    return row

@app.get("/api/solicitudes")
def solicitudes(mine: Optional[int] = 0, user=Depends(get_current_user), conn=Depends(db)):
    if mine:
        if user.get("rol") != "adoptante":
            raise HTTPException(status_code=403, detail="Solo adoptantes pueden ver 'mine=1'")
        q = """
        SELECT
          s.id_solicitud,
          s.id_mascota,
          s.fecha_solicitud,
          s.estado,
          m.nombre AS mascota_nombre
        FROM paw.solicitud_adopcion s
        JOIN paw.mascota_rescatada m ON m.id_mascota = s.id_mascota
        WHERE s.id_adoptante = %s
        ORDER BY s.fecha_solicitud DESC, s.id_solicitud DESC
        LIMIT 200
        """
        return conn.execute(q, (user["id_adoptante"],)).fetchall()

    # Para demo: si no es mine, regresa vacío (se puede hacer fundación después)
    return []

# -----------------------------
# Endpoints: PERFIL ADOPTANTE
# -----------------------------
@app.get("/api/adoptantes/me/perfil")
def perfil_me(user=Depends(require_role("adoptante")), conn=Depends(db)):
    q = "SELECT * FROM paw.adoptante_perfil WHERE id_adoptante = %s"
    row = conn.execute(q, (user["id_adoptante"],)).fetchone()
    return row or {}

@app.put("/api/adoptantes/me/perfil")
def perfil_upsert(payload: PerfilUpsert, user=Depends(require_role("adoptante")), conn=Depends(db)):
    data = payload.model_dump(exclude_unset=True)
    if not data:
        return {"message": "ok", "note": "Sin cambios"}

    # Arrays: psycopg adapta list->array automáticamente
    cols = list(data.keys())
    values = [data[c] for c in cols]

    # Upsert manual: si existe -> UPDATE; si no -> INSERT
    exists = conn.execute(
        "SELECT 1 FROM paw.adoptante_perfil WHERE id_adoptante=%s LIMIT 1",
        (user["id_adoptante"],)
    ).fetchone()

    with conn.transaction():
        if exists:
            set_sql = ", ".join([f"{c}=%s" for c in cols])
            conn.execute(
                f"UPDATE paw.adoptante_perfil SET {set_sql} WHERE id_adoptante=%s",
                (*values, user["id_adoptante"])
            )
        else:
            insert_cols = ", ".join(["id_adoptante"] + cols)
            placeholders = ", ".join(["%s"] * (len(cols) + 1))
            conn.execute(
                f"INSERT INTO paw.adoptante_perfil ({insert_cols}) VALUES ({placeholders})",
                (user["id_adoptante"], *values)
            )

    return {"message": "ok"}
