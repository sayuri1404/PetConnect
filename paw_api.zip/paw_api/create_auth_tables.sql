-- Crea una tabla sencilla de autenticación (porque paw.adoptante no trae password)
-- Ejecuta esto una vez en tu DB.

CREATE TABLE IF NOT EXISTS paw.usuario_auth (
  email          text PRIMARY KEY,
  password_hash  text NOT NULL,
  rol            text NOT NULL CHECK (rol IN ('adoptante','fundacion','donador')),
  id_adoptante   bigint,
  created_at     timestamp without time zone NOT NULL DEFAULT now()
);

-- (Opcional) evitar 2 adoptantes con el mismo email
-- Si ya tienes duplicates, NO lo apliques sin limpiar antes.
-- ALTER TABLE paw.adoptante ADD CONSTRAINT adoptante_email_unique UNIQUE (email);
